curl https://www.andrew.cmu.edu/course/16-726-sp22/projects/handouts/proj1/data.zip -O data.zip
unzip data.zip
